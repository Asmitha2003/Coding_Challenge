package com.hexaware.dto;

import java.time.LocalDate;



public class BookDTO {

	String isbn;
	String title;
	String author;
	LocalDate publicationyear;
	
	public BookDTO()
	{
		
	}

	public BookDTO(String isbn, String title, String author, LocalDate publicationyear) {
		super();
		this.isbn = isbn;
		this.title = title;
		this.author = author;
		this.publicationyear = publicationyear;
	}

	public String getIsbn() {
		return isbn;
	}

	public void setIsbn(String isbn) {
		this.isbn = isbn;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getAuthor() {
		return author;
	}

	public void setAuthor(String author) {
		this.author = author;
	}

	public LocalDate getPublicationyear() {
		return publicationyear;
	}

	public void setPublicationyear(LocalDate publicationyear) {
		this.publicationyear = publicationyear;
	}

	@Override
	public String toString() {
		return "BookDTO [isbn=" + isbn + ", title=" + title + ", author=" + author + ", publicationyear="
				+ publicationyear + "]";
	}
	
	
}
