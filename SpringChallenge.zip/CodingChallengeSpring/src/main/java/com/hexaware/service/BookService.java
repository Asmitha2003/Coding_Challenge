package com.hexaware.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.hexaware.dto.BookDTO;
import com.hexaware.entity.Book;
import com.hexaware.exception.BookAlreadyExistsException;
import com.hexaware.exception.BookNotFoundException;
import com.hexaware.exception.CannotDeleteException;
import com.hexaware.mapper.BookMapper;
import com.hexaware.repository.BookRepository;

@Service
public class BookService {

	@Autowired
	BookRepository repository;
	
	@Autowired 
	BookMapper mapper;
	
	public BookDTO addBooks(BookDTO bdto)
	{
		Book b=mapper.dtoToBook(bdto);
		
		if (repository.existsById(b.getIsbn()))
		{
            throw new BookAlreadyExistsException(
                    "Book with this isbn already exists");
        }
		
		Book b1=repository.save(b);
		BookDTO dto=mapper.BookTodto(b1);
		return dto;
	}
	
	
	public List<BookDTO> showBooks()
	{
	    List<Book> books = repository.findAll();
	    List<BookDTO> bookdtos = new ArrayList<>();
	    for (Book b : books) 
	    {
	        BookDTO dto = mapper.BookTodto(b);
	        bookdtos.add(dto);
	    }

	    return bookdtos;
	}

	
	public BookDTO getBookByISBN(String isbn)
	{
		Book b=repository.findById(isbn)
	                   .orElseThrow(() -> new BookNotFoundException("Book " + isbn + " not found"));
	    
		BookDTO dto=mapper.BookTodto(b);
		return dto;

	}
	
	public String updateBookInfo(String isbn,BookDTO dto)
	{
		Book b=repository.findById(isbn)
                .orElseThrow(() -> new BookNotFoundException("Book " + isbn + " not found"));
 
		Book b1=mapper.dtoToBook(dto);
		b.setTitle(b1.getTitle());
		b.setAuthor(b1.getAuthor());
		b.setPublicationyear(b1.getPublicationyear());
		
		repository.save(b);
		return "Book is updated";
	}
	
	public String deleteBook(String isbn)
	{
		Book b=repository.findById(isbn)
                .orElseThrow(() -> new CannotDeleteException("Book " + isbn + " not found so can't remove"));
		
		repository.delete(b);
		return "Book is deleted";
	}
	
}
