package com.hexaware.exception;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

@RestControllerAdvice
public class GlobalExceptionHandler {

   @ExceptionHandler(BookAlreadyExistsException.class)
   public ResponseEntity<String> handleBookAlreadyExists(BookAlreadyExistsException ex) 
   {
    return new ResponseEntity<>(ex.getMessage(), HttpStatus.BAD_REQUEST);
   }

   @ExceptionHandler(BookNotFoundException.class)
   public ResponseEntity<String> handleBookNotFound(BookNotFoundException ex)
   {
    return new ResponseEntity<>(ex.getMessage(), HttpStatus.NOT_FOUND);
   }
   
   @ExceptionHandler(CannotDeleteException.class)
   public ResponseEntity<String> handleCannotDelete(CannotDeleteException ex)
   {
    return new ResponseEntity<>(ex.getMessage(), HttpStatus.NOT_FOUND);
   }
   
}
