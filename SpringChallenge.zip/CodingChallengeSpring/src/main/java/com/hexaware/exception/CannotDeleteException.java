package com.hexaware.exception;

public class CannotDeleteException extends RuntimeException{
	public CannotDeleteException(String message)
	{
		super(message);
	}

}
