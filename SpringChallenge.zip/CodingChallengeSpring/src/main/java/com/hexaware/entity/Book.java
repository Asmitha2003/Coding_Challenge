package com.hexaware.entity;

import java.time.LocalDate;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;

@Entity
public class Book {
	@Id
	@NotBlank(message = "ISBN must not be blank")
	@Pattern(regexp = "^[0-9]{10}", message = "ISBN must be 10 digits long")
	String isbn;
	@NotBlank(message="Title can't be empty")
	@Size(min = 2, max = 50, message = "Error")
	String title;
	@NotBlank(message="Author must be specified")
	String author;
	@NotNull(message="Date must be specified")
	LocalDate publicationyear;
	
	public Book()
	{
		
	}

	public Book(String isbn, String title, String author, LocalDate publicationyear) {
		super();
		this.isbn = isbn;
		this.title = title;
		this.author = author;
		this.publicationyear = publicationyear;
	}

	public String getIsbn() {
		return isbn;
	}

	public void setIsbn(String isbn) {
		this.isbn = isbn;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getAuthor() {
		return author;
	}

	public void setAuthor(String author) {
		this.author = author;
	}

	public LocalDate getPublicationyear() {
		return publicationyear;
	}

	public void setPublicationyear(LocalDate publicationyear) {
		this.publicationyear = publicationyear;
	}

	@Override
	public String toString() {
		return "Book [isbn=" + isbn + ", title=" + title + ", author=" + author + ", publicationyear=" + publicationyear
				+ "]";
	}
	
	
}
	