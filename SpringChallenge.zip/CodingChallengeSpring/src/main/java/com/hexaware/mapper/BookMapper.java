package com.hexaware.mapper;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.hexaware.dto.BookDTO;
import com.hexaware.entity.Book;

@Component
public class BookMapper {
	
	@Autowired
	ModelMapper modelMap;
	
	public Book dtoToBook(BookDTO dto)
	{
	
	 Book book=modelMap.map(dto, Book.class);
	 return book;
		
	}
	
	public BookDTO BookTodto(Book b)
	{
		
	  BookDTO dto=modelMap.map(b, BookDTO.class);
	  return dto;
		
	}

}
