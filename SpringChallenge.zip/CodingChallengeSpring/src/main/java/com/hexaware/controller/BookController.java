package com.hexaware.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.hexaware.dto.BookDTO;
import com.hexaware.service.BookService;

import jakarta.validation.Valid;

@RestController
@RequestMapping("/book")
public class BookController {

	@Autowired
	BookService service;
	
	
	@PostMapping("/addBook")
	public ResponseEntity<BookDTO> addNewBook(@RequestBody @Valid BookDTO dto)
	{
		BookDTO bdto=service.addBooks(dto);
	    HttpHeaders header = new  HttpHeaders();
		header.add("header Info", "Book added in backend");
		return  new ResponseEntity<>(bdto,header,HttpStatus.CREATED);
	}
	
	
	@GetMapping("/getAllBooks")
	public List<BookDTO> showAllBooks()
	{
		return service.showBooks();
	}
	
	
	@GetMapping("/viewABook/{isbn}")
	public BookDTO getBookByisbn(@PathVariable String isbn)
	{
		return service.getBookByISBN(isbn);
	}

	
	@PutMapping("/updateBook/{isbn}")
	public String updateBook(@PathVariable String isbn,@RequestBody @Valid BookDTO dto)
	{
		return service.updateBookInfo(isbn,dto);
	}
	
	@DeleteMapping("/removeBook/{isbn}")
	public String deleteBook(@PathVariable String isbn)
	{
		return service.deleteBook(isbn);
	}

}
