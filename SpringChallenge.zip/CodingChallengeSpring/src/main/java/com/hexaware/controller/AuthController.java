package com.hexaware.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import com.hexaware.util.JWTUtil;

@RestController
@RequestMapping("/auth")
public class AuthController {

    @Autowired
    private JWTUtil jwtUtil;

    static class LoginRequest {
        public String username;
        public String password;
    }

    @PostMapping("/login")
    public String login(@RequestBody LoginRequest loginRequest) {
        if ("admin".equals(loginRequest.username) && "admin123".equals(loginRequest.password)) {
            return jwtUtil.generateToken(loginRequest.username);
        }
        throw new RuntimeException("Invalid credentials");
    }
}
