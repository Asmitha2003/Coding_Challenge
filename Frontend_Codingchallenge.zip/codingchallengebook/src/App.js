
import { Navigate, Route, Routes } from 'react-router-dom';
import './App.css';
import Login from './Login';
import SignUp from './SignUp';
import AddBook from './AddBook';
import EditBook from './EditBook';
import Books from './Books';

function App() {
  return (
    <>
      <Routes>
      <Route path="/login" element={<Login/>} />
      <Route path="/signup" element={<SignUp/>} />
      <Route path="/" element={<Navigate to="/login"/>} />
      <Route path="/books" element={<Books/>} />
      <Route path="/books/add" element={<AddBook/>} />
      <Route path="/books/:isbn" element={<EditBook/>} />
      </Routes>

    </>
  );
}

export default App;
