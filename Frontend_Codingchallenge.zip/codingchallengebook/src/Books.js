import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import axios from 'axios';
import { Table, Button, Row, Col, Card } from 'react-bootstrap';

const Books = () => {
  const [books, setBooks] = useState([]);

  useEffect(() => {
    fetchBooks();
  }, []);

  const fetchBooks = async () => {
    const token = localStorage.getItem('token');
    try {
      const response = await axios.get('http://localhost:8085/book/getAllBooks', {
        headers: { Authorization: `Bearer ${token}` },
      });
      setBooks(response.data);
    } catch (error) {
      console.error('Error fetching books:', error);
    }
  };

  const deleteBook = (isbn) => {
    const token = localStorage.getItem('token');
    axios.delete(`http://localhost:8085/book/removeBook/${isbn}`, {
      headers: { Authorization: `Bearer ${token}` },
    })
      .then(() => {
        alert('Book deleted successfully!');
        fetchBooks();
      })
      .catch((error) => console.error('Error deleting book:', error));
  };

  return (
    <div
      className="d-flex justify-content-center align-items-center min-vh-100"
      style={{
        background: 'linear-gradient(to right, #e0e6f3ff, #c9dae5ff)',
        padding: '30px',
      }}
    >
      <Card
        className="w-100 shadow-lg p-4"
        style={{
          maxWidth: '1100px',
          backgroundColor: '#fff',
          borderRadius: '20px',
        }}
      >
        <Row className="mb-4">
          <Col>
            <h2 className="text-center fw-semibold text-dark">Book Management</h2>
          </Col>
        </Row>

        <Row className="mb-3">
          <Col className="text-end">
            <Link to="/books/add">
              <Button variant="primary" className="px-4">
                Add New Book
              </Button>
            </Link>
          </Col>
        </Row>

        <Table hover bordered responsive className="table-striped shadow-sm">
          <thead className="table-dark text-center">
            <tr>
              <th>Title</th>
              <th>Author</th>
              <th>Publication Year</th>
              <th>ISBN</th>
              <th>Actions</th>
            </tr>
          </thead>
          <tbody className="text-center align-middle">
            {Array.isArray(books) && books.length > 0 ? (
              books.map((book) => (
                <tr key={book.isbn}>
                  <td>{book.title}</td>
                  <td>{book.author}</td>
                  <td>{book.publicationyear}</td>
                  <td>{book.isbn}</td>
                  <td>
                    <Link to={`/books/${book.isbn}`}>
                      <Button variant="outline-secondary" size="sm" className="me-2">
                        Edit
                      </Button>
                    </Link>
                    <Button
                      variant="outline-danger"
                      size="sm"
                      onClick={() => deleteBook(book.isbn)}
                    >
                      Delete
                    </Button>
                  </td>
                </tr>
              ))
            ) : (
              <tr>
                <td colSpan="5" className="text-center text-muted">
                  No books found.
                </td>
              </tr>
            )}
          </tbody>
        </Table>
      </Card>
    </div>
  );
};

export default Books;
