import React, { useState } from 'react';
import axios from 'axios';
import { Form, Button, Card } from 'react-bootstrap';
import { useNavigate } from 'react-router-dom';

const AddBook = () => {
  const [isbn, setIsbn] = useState('');
  const [title, setTitle] = useState('');
  const [author, setAuthor] = useState('');
  const [publicationyear, setPublicationyear] = useState('');
  const navigate = useNavigate();

  const addBook = (e) => {
    e.preventDefault();

    const book = {
      isbn,
      title,
      author,
      publicationyear
    };

    const token = localStorage.getItem('token');

    axios.post('http://localhost:8085/book/addBook', book, {
      headers: {
        Authorization: `Bearer ${token}`,
        'Content-Type': 'application/json',
      }
    })
    .then(() => {
      alert('Book added successfully!');
      navigate('/books');
    })
    .catch(error => {
      console.error('Error adding book:', error);
      alert('Failed to add book. Please check all fields.');
    });
  };

  return (
    <div
      className="d-flex justify-content-center align-items-center vh-100"
      style={{ background: 'linear-gradient(to right, #dce1e2ff, #d8e5f5ff)' }}
    >
      <Card
        className="p-4 shadow border-0"
        style={{
          width: '100%',
          maxWidth: '500px',
          borderRadius: '15px',
          backgroundColor: '#fff',
        }}
      >
        <h3 className="text-center mb-4">Add New Book</h3>

        <Form onSubmit={addBook}>
          <Form.Group className="mb-3" controlId="formIsbn">
            <Form.Label>ISBN (10-digit)</Form.Label>
            <Form.Control
              type="text"
              placeholder="Enter 10-digit ISBN"
              value={isbn}
              onChange={(e) => setIsbn(e.target.value)}
              pattern="[0-9]{10}"
              required
            />
          </Form.Group>

          <Form.Group className="mb-3" controlId="formTitle">
            <Form.Label>Title</Form.Label>
            <Form.Control
              type="text"
              placeholder="Enter book title"
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              required
            />
          </Form.Group>

          <Form.Group className="mb-3" controlId="formAuthor">
            <Form.Label>Author</Form.Label>
            <Form.Control
              type="text"
              placeholder="Enter author name"
              value={author}
              onChange={(e) => setAuthor(e.target.value)}
              required
            />
          </Form.Group>

          <Form.Group className="mb-3" controlId="formPublicationYear">
            <Form.Label>Publication Year</Form.Label>
            <Form.Control
              type="date"
              placeholder="Enter publication year"
              value={publicationyear}
              onChange={(e) => setPublicationyear(e.target.value)}
              required
            />
          </Form.Group>

          <Button variant="primary" type="submit" className="w-100">
            Add Book
          </Button>
        </Form>
      </Card>
    </div>
  );
};

export default AddBook;
