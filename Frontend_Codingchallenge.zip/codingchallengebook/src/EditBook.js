import React, { useEffect, useState } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import axios from 'axios';
import { Form, Button, Container, Card } from 'react-bootstrap';

function EditBook() {
  const { isbn } = useParams();
  const navigate = useNavigate();
  const [book, setBook] = useState({
    title: '',
    author: '',
    publicationyear: '',
  });

  const token = localStorage.getItem('token');

  useEffect(() => {
    axios.get(`http://localhost:8085/book/viewABook/${isbn}`, {
      headers: { Authorization: `Bearer ${token}` }
    })
    .then(response => {
      setBook(response.data);
    })
    .catch(error => {
      console.error('Error fetching book details:', error);
    });
  }, [isbn]);

  const handleChange = (e) => {
    setBook({ ...book, [e.target.name]: e.target.value });
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    axios.put(`http://localhost:8085/book/updateBook/${isbn}`, book, {
      headers: { Authorization: `Bearer ${token}` }
    })
    .then(() => {
      alert('Book updated successfully');
      navigate('/books');
    })
    .catch(error => {
      console.error('Error updating book:', error);
    });
  };

  return (
    <div
      className="d-flex justify-content-center align-items-center vh-100"
      style={{
        background: 'linear-gradient(to right, #e0f7fa, #f0eafc)',
        padding: '20px',
      }}
    >
      <Card className="p-4 shadow w-100" style={{ maxWidth: '500px' }}>
        <h3 className="text-center mb-4">Edit Book</h3>
        <Form onSubmit={handleSubmit}>
          <Form.Group className="mb-3" controlId="formTitle">
            <Form.Label>Title</Form.Label>
            <Form.Control
              type="text"
              name="title"
              value={book.title}
              onChange={handleChange}
              required
            />
          </Form.Group>

          <Form.Group className="mb-3" controlId="formAuthor">
            <Form.Label>Author</Form.Label>
            <Form.Control
              type="text"
              name="author"
              value={book.author}
              onChange={handleChange}
              required
            />
          </Form.Group>

          <Form.Group className="mb-3" controlId="formYear">
            <Form.Label>Publication Year</Form.Label>
            <Form.Control
              type="text"
              name="publicationyear"
              value={book.publicationyear}
              onChange={handleChange}
              required
            />
          </Form.Group>

          <Button type="submit" variant="success" className="w-100">
            Update Book
          </Button>
        </Form>
      </Card>
    </div>
  );
}

export default EditBook;
